<?php
$app = include_once('bootstrap.php');

$app->runWithRoute('index');
