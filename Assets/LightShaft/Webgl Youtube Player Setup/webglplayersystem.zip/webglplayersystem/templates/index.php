<?php echo $this->inc('header.php', ['title' => 'Youtube Downloader']); ?>
		<h1 class="form-download-heading">LightShaft youtube video for unity</h1>
		<p>This is a workaround for webgl, there's no way to speed up the process to get the video, will be faster only if you use no protected videos.</p>
<hr />
<?php echo $this->inc('footer.php'); ?>
