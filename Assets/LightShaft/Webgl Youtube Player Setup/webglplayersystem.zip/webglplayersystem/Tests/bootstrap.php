<?php

require_once 'PHPUnit/TextUI/TestRunner.php';
require 'vendor/autoload.php';
